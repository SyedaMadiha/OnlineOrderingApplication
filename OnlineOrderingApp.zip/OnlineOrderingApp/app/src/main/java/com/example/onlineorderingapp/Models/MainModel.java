package com.example.onlineorderingapp.Models;

public class MainModel {
}
